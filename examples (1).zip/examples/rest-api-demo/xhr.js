
var clientid = "";
var laststatus = 200;

function doGet(url, accepthdr, processfunc, outputelement, rawoutputelement, needsauthorization, async) {
  submitRequest("GET", url, accepthdr, null, processfunc, null, outputelement, rawoutputelement, needsauthorization, async );
}

function doPost(url, accepthdr, contenttypehdr, processfunc, messagebody, outputelement, rawoutputelement, needsauthorization, async) {
  submitRequest("POST", url, accepthdr, contenttypehdr, processfunc, messagebody, outputelement, rawoutputelement, needsauthorization, async );
}

function doPut(url, accepthdr, contenttypehdr, processfunc, messagebody, outputelement, rawoutputelement, needsauthorization, async) {
  submitRequest("PUT", url, accepthdr, contenttypehdr, processfunc, messagebody, outputelement, rawoutputelement, needsauthorization, async );
}

function doDelete(url, processfunc, outputelement, rawoutputelement, needsauthorization, async ) {
  submitRequest("DELETE", url, null, null, processfunc, null, outputelement, rawoutputelement, needsauthorization, async );
}

//
// Issue an HTTP request using the method, url, and headers specified.  The specified processing function
// is called to handle the response.  The outputelement is the DOM element to which the output is to be appended.
// The rawoutputelement is the DOM element to which the raw output is to be shown (for displaying JSON).
// Arguments to doGet() include the method, url, the Accept header value, the Content-Type header value (POST and PUT only), the
// response processing function, the message body (POST and PUT only), the DOM element to be used as the place where the output
// goes, the DOM element where the raw output goes, and an indicator as to whether the request needs authorization.  The last parameter
// can be used to specify if the request is to be processed asynchronously; the default is true.
// The request to get repositories does not require authorization; other navigation requests do.
//
function submitRequest(method, url, accepthdr, contenttypehdr, processfunc, messagebody, outputelement, rawoutputelement, needsauthorization, async) {
  var root = document.getElementById("rooturl").value;
  var xhttp;
  xhttp=new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 ) {
      if ( this.status == 200 || this.status == 204 || this.status == 201 ) {
        if ( processfunc != null ) processfunc(xhttp.responseText, outputelement, rawoutputelement);
        clientid = xhttp.getResponseHeader("client-id");
      }
      else {
        var responseObj = JSON.parse(xhttp.responseText);
        rawoutputelement.innerHTML = "<pre>" + JSON.stringify(responseObj,null,'\t') + "<pre>";
        alert( "HTTP error status returned: " + this.status + ".  After dismissing this dialog, see raw output for details.");
        laststatus = this.status;
      }
    }
  };
  if ( typeof async == 'undefined' ) xhttp.open(method, root + url, true);
  else xhttp.open(method, root + url, async);
  if ( needsauthorization ) {
    var authheaderarray = [];
    authheaderarray = getAuthorizationHeaders();
    for ( i = 0; i < authheaderarray.length; i++ ) {
	  xhttp.setRequestHeader(authheaderarray[i].name, authheaderarray[i].value);
	}
  }
  if ( clientid != "" ) xhttp.setRequestHeader("client-id", clientid);
  if ( typeof accepthdr != 'undefined' && accepthdr != null ) xhttp.setRequestHeader("Accept", accepthdr);
  if ( typeof contenttypehdr != 'undefined' && contenttypehdr != null ) xhttp.setRequestHeader("Content-Type", contenttypehdr);
  if ( typeof messagebody != 'undefined' && messagebody != null ) xhttp.send(messagebody);
  else xhttp.send();
}

//
// Expose the clientid to callers needing to submit forms, which must include 'client-id' as a form field.
//
function getClientId() {
  return clientid;
}

//
// Clear the client id.
//
function clearClientId() {
  clientid = "";
}
