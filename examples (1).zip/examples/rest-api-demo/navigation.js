//
// handlers is an array of handler object identifying the following:
//  handlerstag is a unique tag
//  getchildrenclickhandler is the click handler for when a list item is clicked that is not a document.
//  documentclickhandler is the click handler for when a list item is clicked that is a document.
//  listitemdecorator is a function to be invoked for every list item created during navigation.
//
var handlers = [
  { handlerstag : "default",
    getchildrenclickhandler : new Function("getChildren(event)"),
    documentclickhandler : new Function("noop(event)"),
    listitemdecorator : new Function("noop(event)")
  }
];

//
// getHandlers retrieves the handers associated with a specific tag.
//
function getHandlers(handlerstag) {
  var handlersInstance = handlers[0];
  if ( typeof handlerstag == 'undefined' || handlerstag == null ) return handlers[0];
  handlers.forEach(function(element) {
    if ( typeof element.handlerstag != 'undefined' && element.handlerstag == handlerstag ) {
      handlersInstance = element;
	}
  });
  return handlersInstance;
}

//
// registerHandlers registers the specified handlers/listitemdecorator with the specified tag.  It creates
// a new Object to hold them, then pushes the object to the handlers array.
//
function registerHandlers(handlerstag, getchildrenclickhandler, documentclickhandler, listitemdecorator ) {
	var handlersInstance = new Object();
	handlersInstance.handlerstag = handlerstag;
	if ( typeof getchildrenclickhandler != 'undefined' && getchildrenclickhandler != null )
	  handlersInstance.getchildrenclickhandler = getchildrenclickhandler;
	else handlersInstance.getchildrenclickhandler = new Function("getChildren(event)");
	if ( typeof documentclickhandler != 'undefined' && documentclickhandler != null )
	  handlersInstance.documentclickhandler = documentclickhandler;
	else handlersInstance.documentclickhandler = new Function("noop(event)");
	if ( typeof listitemdecorator != 'undefined' && listitemdecorator != null )
	  handlersInstance.listitemdecorator = listitemdecorator;
	else handlersInstance.listitemdecorator = new Function("noop(event)");
	handlers.push(handlersInstance);
}

//
// A simple no-op function.
//
function noop(event) {
  if ( typeof event != 'undefined' && event != null )
    event.stopPropagation();
  return null;
}

//
// Get the children of the folder item on which the click event was triggered.
//
function getChildren(event) {
  event.stopPropagation();
  var listItem = event.target;

  var url = listItem.getAttribute("url");
  var expanded = listItem.getAttribute("expanded");
  var accepthdr = listItem.getAttribute("accepthdr");
  if (expanded == "false")
    doGet(url, accepthdr, processnavresponse, listItem, getrawoutputdiv(), true);
  else deleteChildren(listItem);

}

//
// Delete the children of the folder item on which the click event was triggered.  This 'collapses' the tree.
//
function deleteChildren(listItem) {
  listItem.removeChild(listItem.lastChild);
  listItem.setAttribute("expanded", "false");
}

//
// Process an HTTP reponse. The responseText is the content of the response body as text; it is JSON.
// The outputelement is the element to which the output is to be appended.
// The rawoutputelement is the element to which the raw output is to be shown.
//
function processnavresponse(responseText, outputelement, rawoutputelement) {
  var response = JSON.parse(responseText);
  var nodesList = document.createElement("ul");
  var rel = ""; // for getting children
  var delrel = ""; // for deleting
  var postrel = ""; // for creating
  var selfrel = "self";

  outputelement.appendChild(nodesList);
  var handlerstag = outputelement.getAttribute("handlerstag");
  var repositoryId = outputelement.getAttribute("repositoryId");

  // Process each returned item.
  for ( i = 0; i < response.items.length; i++ ) {
    var listItem = document.createElement("li");
    if ( typeof response.items[i].name != 'undefined' )
      listItem.appendChild(document.createTextNode(response.items[i].name));
    else if ( typeof response.items[i].displayName != 'undefined' )
      listItem.appendChild(document.createTextNode(response.items[i].displayName));
    else
      listItem.appendChild(document.createTextNode("Unknown"));

    // Assume all items the same; use item[0] to determine if folder or document.
    if ( "baseTypeId" in response.items[0] && response.items[0].baseTypeId == "DOCUMENT") {
      rel = "http://www/asg/com/mobius/rel/document";
      listItem.addEventListener("click", getHandlers(handlerstag).documentclickhandler, false);
    }
    else {
      if ( typeof response.items[i].nodeType != 'undefined' ) {
		if ( response.items[i].nodeType == "favoritesFolder" ) {
          rel = "http://www/asg/com/mobius/rel/favorites/children";
          listItem.setAttribute("accepthdr", "application/vnd.asg-mobius-favorite-list.v1+json");
          listItem.addEventListener("click", getHandlers(handlerstag).getchildrenclickhandler, false);
	    }
        delrel = "http://www/asg/com/mobius/rel/favorites/delete";
        postrel = "http://www/asg/com/mobius/rel/favorites/create";
	  }
	  else {
	    rel = "http://www/asg/com/mobius/rel/children";
        listItem.setAttribute("accepthdr", "application/vnd.asg-mobius-navigation.v1+json");
        listItem.addEventListener("click", getHandlers(handlerstag).getchildrenclickhandler, false);
	  }
    }

    // Find the HATEOAS link for the rel that we are interested in.
    for ( j = 0; j < response.items[i].links.length; j++ ) {
      if ( response.items[i].links[j].rel == rel )
        listItem.setAttribute("url", response.items[i].links[j].href);
      if ( response.items[i].links[j].rel == delrel )
        listItem.setAttribute("delurl", response.items[i].links[j].href);
      if ( response.items[i].links[j].rel == postrel )
        listItem.setAttribute("posturl", response.items[i].links[j].href);
    }

    listItem.setAttribute("expanded", "false");
    listItem.classList.add('listitem');
    if ( typeof response.items[i].repositoryId != 'undefined' ) {
		listItem.setAttribute("nodeType", "repository" );
		listItem.setAttribute("repositoryId", response.items[i].repositoryId);
	}
    else if ( repositoryId != "" ) listItem.setAttribute( "repositoryId", repositoryId);
    if ( typeof response.items[i].nodeType != 'undefined' ) listItem.setAttribute("nodeType", response.items[i].nodeType );
    if ( typeof response.items[i].baseTypeId != 'undefined' ) listItem.setAttribute("baseTypeId", response.items[i].baseTypeId );
    if ( typeof response.items[i].objectTypeId != 'undefined' ) listItem.setAttribute("objectTypeId", response.items[i].objectTypeId );
    if ( typeof response.items[i].objectId != 'undefined' ) listItem.setAttribute("objectId", response.items[i].objectId );

    getHandlers(handlerstag).listitemdecorator(listItem);
    if ( handlerstag != null ) listItem.setAttribute( "handlerstag", handlerstag );
    nodesList.appendChild(listItem);

  }
  outputelement.setAttribute("expanded", "true");
  var finalResponse=JSON.stringify(response,null, '\t');
  rawoutputelement.innerHTML = "<pre>" + finalResponse + "</pre>";
}

