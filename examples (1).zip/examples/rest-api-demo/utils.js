//
// Utility functions used throught the samples.
//

// Create a radio button with the specified id (also used for the value), group, and checked state.
function createRadioButton(id, group, checked) {
  var radio = document.createElement('input');
  radio.type= 'radio';
  radio.id = id;
  radio.name = group;
  radio.value = id;
  radio.checked = checked;
  return radio;
}

// Create a text input field with the specified id and size.
function createTextInputField(id, size) {
  var textinput = document.createElement('input');
  textinput.type= 'text';
  textinput.id = id;
  textinput.size = size;
  return textinput;
}

// Create a checkbox with the specified value (used to set its checked state) and id.
function createCheckbox(value, id) {
  var checkbox = document.createElement('input');
  checkbox.type= 'checkbox';
  checkbox.id = id;
  checkbox.checked = value;
  return checkbox;
}

// Add a button to the specified element (listItem).
function addButtonToItem(listItem, text, eventlistener) {
  var button = document.createElement("BUTTON");
  var text = document.createTextNode(text);

  button.appendChild(text);
  button.addEventListener("click", eventlistener, false);
  button.setAttribute('style', "margin: 0px 5px;");

  listItem.appendChild(button);
}
