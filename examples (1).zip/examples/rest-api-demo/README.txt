REST API DEMO description

The REST API DEMO provides JavaScript samples for invoking the Mobius REST API.  Each REST API, or group of related APIs, is represented by a 
separate .html file that includes HTML markup to display a simple user interface appropriate for that API, along with JavaScript code for invoking
that API.  In addition to the API-specific files, there are a small number of common files for providing shared functionality.  The samples are
written in 'vanilla' JavaScript; JQuery is used exclusively for loading individual samples files in sampleroot.html.

Note that /mobius is the assumed context throughout the examples.

The following text describes the files provided.  To avoid cross-origin request problems, you should deploy the example files into a sub-directory under the webapps
directory on your web server that is serving the REST API.

sampleroot.html
In order to run the samples, load sampleroot.html as follows in your browser address bar (in this example, the sample files were copied into webapps\rest-api-demo):

    https://<host>:<port>/rest-api-demo/sampleroot.html

The sampleroot.html file is the root file of the demo samples.  This file defines a button to launch each sample, along with a button to unload the current sample module.
It also provides an input field to define the 'root' url to be used for testing and a test button to exercise it; this test button simply issues a request to get a list of
repositories (which does not require authentication).  The word 'success' or 'failure' is displayed to the right of the button to indicate its status.  The root URL will be
automatically populated with the protocol, host, and port you used when launching the sampleroot.html file.  These defaults should be correct and should not require modification.

This file automatically loads the Authorization Sample module (sampleauth.html) and the Output Sample module (sampleoutput.html).  These modules, displayed in individual 
<div>s, are potentially required by all other samples, and are consequently always visible.  

When a sample is loaded by clicking its button, it replaces any currently loaded sample.  


sampleauth.html
This sample module includes the HTML markup defining the user interface for authorization features, as well as the JavaScript needed to implement those features.
Each repository configured for 'prompting' requires authorization; to use such a repository, its name or id, along with its credentials, must be entered into the
appropriate fields in the 'Authorization' panel, and the 'Generate Authorization Value' button clicked.  The repository will subsequently be represented in a list in
the 'Repositories With Generated Authorization Values' panel.  Clicking on an item in the list will remove it.  Details regarding the required headers and values to 
support authorization can be obtained from the code comments, and from the product documentation.


sampleoutput.html
This sample module includes the HTML markup defining the user interface for generalized output features, as well as the JavaScript needed to implement those features.
All the samples need to produce output of some sort.  This module provides a consistent user interface for that ouput.  It defines two <div>s for that purpose; one,
defined with the id 'output', is used for displaying formatted output using HTML user interface elements.  The other, defined with the id 'rawoutput', is intended for
displaying the raw JSON returned by a REST API call.


xhr.js
This JavaScript file includes the shared code for invoking REST API services using the XMLHTTPRequest object.  The 'doGet', 'doPost', 'doPut', and 'doDelete'
functions correspond to the GET, POST, PUT, and DELETE HTTP methods.  Each of these functions allow the specification of parameters appropriate to the HTTP method
being used, including the accept header, the content-type header, and a message body; as well as a response processing function, an output element (to which
formatted HTML data is written), a raw output element (to which 'raw' JSON response text is written), a flag to indicate if the request needs authorization, and
a flag which indicates if the request should be invoked asynchronously (may be ignored by some browsers).  These functions all call the 'submitRequest' function, 
which creates, opens, and sends the request.  If the request is identified as needing authorization, the appropriate request headers are configured and sent with 
the request.  The 'client-id' response header is saved and resent on subsequent requests.  For further information about authorization, see the product documentation, 
along with the description of, and code comments in, the sampleauth.html module.


navigation.js
This JavaScript file includes the shared code needed for processing the response from navigation REST API calls.  The main response processing function in 
this file is 'processnavreponse'; it processes the response from a call to the REST API navigation services, and creates an unordered list <ul> to represent 
the returned folders and documents, each being represented by a list item <li>.  

Each list item representing a folder is assigned a click handler specific to folder processing; the default click handler, function 'getChildren', gets the children 
of the item clicked.

Each list item representing a document is assigned a click handler specific to document processing; the default click handler does nothing.

Many of the samples require navigation services as a prelude to demonstrating their specific features, but require different handling of the returned response.  
In order to provide the flexibitily needed for handling the navigation response in a sample-specific way, the caller may specify click handlers for list items 
representing folders and documents, as well as a post-processing function for decorating each list item.  The way a caller controls this behavior is by calling
the 'registerHandlers' function, which accepts four parameters: (1)a tag that identifies the objects to which the handlers apply; (2)the handler function to be 
used when a folder is clicked (typically, for getting the children of the folder); (3)the handler function to be user when a document is click (potentially to 
retrieve and download the content of the document); and (4)the function to be used as a decorator for a clicked list item (for example, to append buttons or other
user interface elements that are required for a specific sample).  Null or empty values for the handler or decorator parameters cause default behavior to be invoked.  
The caller must additionally assign the tag as the value of an attribute with the name 'handlerstag' on the output element passed to the 'processnavresponse' function; 
this attribute is inherited by all list items subsequently added to the output element, along with the click handlers and list item decorator associated with it.

The usage of the click handlers and list item decorator will become clear as their use in the various samples is described below.


util.js
This file contains a small number of utility functions used throughout the samples.


samplenavcont.html
This sample module includes the HTML markup defining the user interface for navigation and content retrieval features, as well as the JavaScript needed to implement 
those features.  Clicking the 'Get Repositories' button calls the 'getRepositories' function, which issues a call to 'registerHandlers' to register the 'downloaddocument' 
function as the document click handler, so that when a document is clicked, its content is downloaded.  It then issues a 'doGet' function call to the REST API navigation service 
to retrieve a list of repositories; each repository is displayed in a list in the Output panel, and the 'raw' JSON representing the response is displayed in the Raw Output
panel.  Each repository can then be navigated by clicking its name in the list; if configured for 'prompting', its authorization value must first be generated.  The repository
hierarchy can be navigated to the point of retrieving a list of documents; clicking a document will result in its download.  Parameters for content retrieval can be specified
in advance using the provided user interface controls.


samplesearch.html
This sample module includes the HTML markup defining the user interface for search features, as well as the JavaScript needed to implement those features.  
The 'Get List of Searches' button will get a list of searches and display them in the Output panel, along with the 'raw' JSON in the Raw Output panel.
The 'Save Search' button will save the search defined in the search definition text area field; the 'raw' JSON will be displayed in the Raw Output panel.
The 'Execute Search' button will execute the search defined in the search definition text area field; the 'raw' JSON will be displayed in the Raw Output panel.  The 
'Maximum results' input field allows you to specify the maximum number of results to be returned by the search.

In the Output Panel, each listed search will have buttons to 'Get', 'Delete', 'Modify', and 'Execute' that search.  An input field allows you to specify the maximum number 
of results to be returned by the specific search from the list that was executed.

The 'Get' button will retrieve the definition of the search associated with the button, show its definition in the search definition text area, and show the 'raw' JSON in the Raw Output panel.
The 'Delete' button will delete the search associated with the button.
The 'Modify' button will modify the search associated with the button by applying the definition in the search definition text area.
The 'Execute' button will execute the search associated with the button.  

In all cases, the Raw Output will show the JSON returned by the request.


samplefavorites.html
This sample module includes the HTML markup defining the user interface for favorites features, as well as the JavaScript needed to implement those features.  The user interface that is presented
shows two trees, one representing the repositories that can be navigated from which items can be added as favorites, and one representing the currently defined favorites and favorite folders.
Each item in the repository tree hierarchy that can be added as a favorite has an 'Add' button associated with it.  Each item in the favorites tree that is a folder has two buttons, 'Del' (to
delete it) and 'New Folder' (to create a new favorites folder at that location).  Each item in the favorites tree that is not a favorites folder has a single 'Del' button to delete it.

Clicking the 'Get Repositories' button calls the 'getRepositories' function, which calls function 'setupdivs' to set up the <div>s needed for the UI (one <div> for repositories, and 
one <div> for favorites), and assigns click handlers and item list decorators (it calls 'registerHandlers' to register the appropriate handlers for the repository tree and for the favorites
tree).  The click handler for favorites ('getfavoriteschildrenhandler') allows navigating the favorites folders, but not other types of folders like reports or topics (it calls 'getChildren' 
only if the 'nodetype' is 'favoritesFolder'); it also populates the 'folderName' field with whatever folder was clicked on.  The item list decorator for repositories (function 'decoratefavnavtreelistitem')
appends an 'Add' button to non-repository items, allowing that item to be added as a favorite to the folder whose name is specified in the Folder Name input field.  The item list decorator 
for favorites (function 'decoratefavnavfolderslistitem') adds a 'Delete' button to every favorite, and adds a 'New Folder' button to favorite folders.

The 'getRepositories' function then issues two calls to 'doGet', once to get a list of repositories, and once to get a list of favorites; in each case, the appropriate headers are specified, 
along with individual processing methods to handle the REST API response, and the appropriate <div> for formatted output.  The processing method for favorites ('processfavoriteresponse') creates 
the user interface elements to represent the Folder Name input field and the Root Folder node, and then calls 'processnavresponse' to further process the list to produce the list representing the
favorites returned by the request.


samplehostviewer.html
This sample module includes the HTML markup defining the user interface for generating a Host Viweer URL, as well as the JavaScript needed to implement those features.  
The user interface exposes a 'Get Repositories' button that is mapped to function 'getRepositories'.  This function registers a list item handler called 'decoratehosturltreelistitem' that adds a button 
called "Generated Host Viewer URL" to items that are documents, to generate the host viewer URL; the handler for this button is function 'generateHostViewerUrl'.  Then, the function issues a doGet call to get 
the repository list; the response processing function is specified to be 'processhostviewerresponse'.  When 'processhostviewerresponse' gets control with the result of the request, it creates the user 
interface elements for holding the generated URL, input fields for the userid and password, and a 'submit' button to launch the generated URL.  Then, the default 'processnavresponse' function is called to 
produce the repository list for navigation.

Clicking on the "Generated Host Viewer URL" button on a document causes the 'generateHostViewerUrl' function to get control; it issues a doPost request to the Host Viewer REST API service, specifying 
response processing function 'processgenhostviewerurlresponse'.  When  'processgenhostviewerurlresponse' gets control, it copies the generated URL into the 'hostviewerurl' input field to display it, 
and also sets the 'dc' parameter on the form which, when submitted, will launch view to display the document.


samplerepcap.html
This sample module includes the HTML markup defining the user interface for obtaining repository capabilities, as well as the JavaScript needed to implement those features.  
The user interface exposes a 'Get Repositories' button that is mapped to function 'getRepositoriesForCapabilities'.  This function registers a list item handler called 'decoraterepocaplistitem' that 
adds a button called "Get Capabilities" to items that are repositories, to retrieve the capabilities for that repository; the handler for this button is function 'showrepocapabilities'.  This
function additionally registers a click handler called 'getrepocapchildrenhandler', which disallows navigation altogether; we only want repositories in the list.  Then, the function issues a doGet call 
to get the repository list; the response processing function is specified to be the default 'processnavresponse' function.

Clicking on the "Get Capabilities" button on a repository causes the 'showrepocapabilities' function to get control; it issues a doGet request to the Repository Capabilities REST API service, 
specifying response processing function 'processRepCapResponse'.  When  'processRepCapResponse' gets control, it copies the JSON response text to the Raw Output panel, showing the returned capabilities for
the repository.


samplerecordtype.html
This sample module includes the HTML markup defining the user interface for obtaining record types, as well as the JavaScript needed to implement those features.  
The user interface exposes a 'Get Repositories' button that is mapped to function 'getRepositoriesForRecordTypes'.  This function creates the user interface components for specifying optional request
parameters ('scope' and 'result set type'), and a button ("Get Record Types for all repositories") to retrieve the record types for all repositories (the click handler for the button is function 'showrecordtypes').  Then, it registers a list 
item handler called 'decoratereporectypelistitem' that adds a button called "Get Record Types" to items that are repositories, to retrieve the record types for that repository; the handler for this button 
is function 'showrecordtypes'.  This function additionally registers a click handler called 'getreporectypechildrenhandler', which disallows navigation altogether; we only want repositories in the list.  
Then, the function issues a doGet call to get the repository list; the response processing function is specified to be the default 'processnavresponse' function.

Clicking on the "Get Record Types" button on a repository, or on the "Get Record Types for all repositories" button, causes the 'showrecordtypes' function to get control; it issues a doGet request to the 
Record Types REST API service (either for a specific repository or for all of them), specifying response processing function 'processRecordTypesResponse'.  When  'processRecordTypesResponse' gets control, 
it copies the JSON response text to the Raw Output panel, showing the returned record types.


sampleindexes.html
This sample module includes the HTML markup defining the user interface for obtaining indexes, as well as the JavaScript needed to implement those features.  
The user interface exposes a 'Get Repositories' button that is mapped to function 'getRepositoriesForIndexes'.  This function creates the user interface components for specifying optional request
parameters ('scope', 'result set type', and 'document class'), and a button ("Get Indexes for all repositories") to retrieve the indexes for all repositories (the click handler for the button is function 
'showindexes').  Then, it registers a list item handler called 'decorateindexlistitem' that adds two buttons to each repository: a button called "Get Indexes" to retrieve the indexes for that 
repository (the handler for this button is function 'showindexes'), and a button called "Get Indexes (Document Based)" to get only document-class based indexes (the handler for this button is function 
'showindexesdocumentbased').  This function additionally registers a click handler called 'getrepoindexchildrenhandler', which disallows navigation altogether; we only want repositories in the list.  
Then, the function issues a doGet call to get the repository list; the response processing function is specified to be the default 'processnavresponse' function.

Clicking on the "Get Indexes" button on a repository, or on the "Get Indexes for all repositories" button, causes the 'showindexes' function to get control; it issues a doGet request to the 
Indexes REST API service (either for a specific repository or for all of them), specifying response processing function 'processIndexesResponse'.  Clicking on the "Get Indexes (Document Based)"
button causes the 'showindexesdocumentbased' function to get control; it issues a doGet request to the Indexes REST API service to retrieve repostiory indexes associated with a document class,
specifying response processing function 'processIndexesResponse'.  

When  'processIndexesResponse' gets control, it copies the JSON response text to the Raw Output panel, showing the returned indexes.


sampleeventtemplates.html
This sample module includes the HTML markup defining the user interface for obtaining Records Management Event Templates, as well as the JavaScript needed to implement those features.
The 'Get List of Event Templates' button will get a list of event templates and display them in the Output panel, along with the 'raw' JSON in the Raw Output panel.
The 'Save Event Template' button will save the event template defined in the event template definition text area field; the 'raw' JSON will be displayed in the Raw Output panel.

In the Output Panel, each listed event template will have buttons to 'Get', 'Delete', 'Modify', and 'Disable' that event template.

The 'Get' button will retrieve the definition of the event template associated with the button, show its definition in the event template definition text area, and show the 'raw' JSON in the Raw Output panel.
The 'Delete' button will delete the event template associated with the button.
The 'Modify' button will modify the event template associated with the button by applying the definition in the event template definition text area.
The 'Disable' button will disable the event template associated with the button.

In all cases, the Raw Output will show the JSON returned by the request.


sampleevents.html
This sample module includes the HTML markup defining the user interface for obtaining Records Management Event Processing, as well as the JavaScript needed to implement those features.
The 'Get List of Events by Search' button will get a list of RETENTION_CHANGE_BY_SEARCH events and display them in the Output panel, along with the 'raw' JSON in the Raw Output panel.
The 'Get List of Events by Document' button will get a list of RETENTION_CHANGE_BY_DOCUMENTS events and display them in the Output panel, along with the 'raw' JSON in the Raw Output panel.
The 'Get List of Rescind Events' button will get a list of RETENTION_RESCIND_BY_REASON events and display them in the Output panel, along with the 'raw' JSON in the Raw Output panel.
The 'Post Event' button will post the event defined in the event definition text area field; the 'raw' JSON will be displayed in the Raw Output panel.

In the Output Panel, each listed event will have buttons to 'Get', 'Get Status', 'Reprocess', and 'Delete' that event.

The 'Get' button will retrieve the definition of the event associated with the button, show its definition in the event definition text area, and show the 'raw' JSON in the Raw Output panel.
The 'Get Status' button will display the status of the event associated with the button in the Raw Output panel.
The 'Reprocess' button will reprocess the event associated with the button.
The 'Delete' button will delete the event associated with the button.

In all cases, the Raw Output will show the JSON returned by the request.


sampleretentions.html
This sample module includes the HTML markup defining the user interface for obtaining Records Management Retentions, as well as the JavaScript needed to implement those features.
The 'Get List of Retentions' button will get a list of retention reasons and display them in the Output panel, along with the 'raw' JSON in the Raw Output panel.

There are no associated HATEOAS links.


samplepolicies.html
This sample module includes the HTML markup defining the user interface for obtaining Records Management Retention Policies, as well as the JavaScript needed to implement those features.
The 'Get List of Policies' button will get a list of retention policies and display them in the Output panel, along with the 'raw' JSON in the Raw Output panel.
The 'Save Policy' button will save the retention policy defined in the policy definition text area field; the 'raw' JSON will be displayed in the Raw Output panel.

In the Output Panel, each listed retention policy will have buttons to 'Get', 'Delete', 'Modify', and 'Disable' that retention policy.

The 'Get' button will retrieve the definition of the retention policy associated with the button, show its definition in the policy definition text area, and show the 'raw' JSON in the Raw Output panel.
The 'Delete' button will delete the retention policy associated with the button.
The 'Modify' button will modify the retention policy associated with the button by applying the definition in the policy definition text area.
The 'Disable' button will disable the retention policy associated with the button.

In all cases, the Raw Output will show the JSON returned by the request.

samplearchivewrite.html
This sample module includes the HTML markup defining the user interface for archiving documents, as well as the JavaScript needed to implement those features.  The sample allows you to
archive one document at a time.  This sample demonstrates the four variants of archiving, but does not demonstrate the use of all the various available query parameters that can be used
to fine-tune the archiving behavior.

The four variants of archiving are:

    Archive using explicit metadata with the file to be archived identified using a URL in the request
    Archive using explicit metadata with the content of the file to be archived embedded within the request
    Archive using policies with the file to be archived identified using a URL in the request
    Archive using policies with the content of the file to be archived embedded within the request

When launched, this module displays two side-by-side panels.  The left side panel allows you to select the file to be archived, and the report and indexing constraints to be used.  The
right side panel shows the options that will be used when the 'Archive' button is pressed; they reflect choices that were made on the left side of the screen.  As you make selections on the
left, the right side panel is updated to reflect those selections.

The 'Select the repository to use for archiving' drop-down list provides a list of repositories.  The one selected is subsequently displayed in the right-hand panel.  If this repository
is configured for prompting authentication, be sure to use the 'Authorization' module to specify its credentials.

The 'Select how the content is to be indexed' section displays two mutually-exclusive radio buttons:

    'Using explicit metadata' means that the document will be archived using the specific topics and values specified.  All topic ids specified must be defined to VDRNET.  The 'Add topics
    and values to the list on the right here' control allows you to specify a topic id and topic value.  Clicking the 'Add' button adds the topic/value pair to the right side.  Multiple
    topic/value pairs can be specified.  The special name 'SECTION' can be used for a topic id to indicate the section name to be used when archiving the report.  In the right-side panel,
    clicking on a topic/value pair will remove it from its list.

    'Using one or more policies' means that the document will be archived using the specified policy or policies.  All policies must be defined to VDRNET.  The 'Add policies to the list on
    the right here' control allows you to specify a policy.  Clicking the 'Add' button adds the policy to the right side.  Multiple policies can be specified.  In the right-side panel,
    clicking on a policy will remove it from its list.

The 'Specify the report id and type' section allows you to specify the report id and report type to use.  The report id is optional when using policy archiving, but if specified, it overrides
the policy.  The type is optional.  Clicking the 'Add' button associated with the 'report id' field adds it to the right side.  Clicking the 'Add' button associated with the 'type' field
adds it to the right side.

The 'Select the content to be archived (along with any external metadata when using policies)' section displays two mutually-exclusive radio buttons:

    'Use a URL to reference the file being archive' means that the file you archive is identified with a string in the form <drive>:<path>:<filename>.<ext>.  The 'File to be archived' control
    allows you to specify the file.  Use the 'Add' button to add the file to the right side.  The 'File with external metadata' control allows you to specify a file with external metadata used
    for additional indexing information.  Use the 'Add' button to add the file to the right side.  File references must be accessible to the Mobius (VDRNET) server.

    'Embed the content of the file to be archived in the request' mean that the content of the file to be archived is embedded in the request.  'Use this file picker to select the file' lets
    you pick the file to be archived; it is automatically reflected on the right side.  The 'Content Type' field allows you to define the MIME type; use the 'Add' button to add it to the right
    side.  The 'Specify external metadata below' field indicates that additional metadata to be used for indexing will be explicitly specified in the text area below; enter the metadata and
    click the 'Add' button to add it to the right side.

When the archiving constraints have been specified, verify they are correct on the right side panel.  Then, click the 'Archive' button.  This initiates the archive request; the Raw Output
will display the response; barring an error, it will usually indicate that the operation is incomplete but in progress.  Use the 'Get Archive Status' button repeatedly to get ongoing archive
status until it shows that the operation completed successfully, or that an error occurred.
