#!/bin/bash
# !!! Before using this script, replace variables below with appropriate values
export PROTOCOL="https"
export HOST_STRING="127.0.0.1:17443"
# The AUTHORIZATION_STRING uses standard base64 encoding of user:password (https://www.base64encode.org/ will encode your string for you.)
export AUTHORIZATION_STRING="Basic YWRtaW46YWRtaW4="
export DOCUMENT_ID="ENC(OC5yZXBvcnRpZDEwLkFDMDAxX1JTUlY5LnJlcG9ydHZlcjE0LjIwMTYxMTE2MTY1NjAzMTAucmVwb3J0c2VjdDQ1LiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDAwMDAwMDAwMDYwMDAwMDEwLm9yZ3BhZ2VudW0xLjExMy5udW1iZXJvZnBhZ2VzMS43MTAucmVwb3NpdG9yeTE2LnZkcmRldl9yZWRhY3Rpb24xMi5yZXBvc2l0b3J5aWQzNi4wMEM5QTY1Ni00QUJBLTRFQzMtODRFNS04OEY3NTlBOUFCQTYxNi50Y2ljcnlwdG92ZXJzaW9uMy4xLjA)"
export FOLDER_ID="ENC(OC5yZXBvcnRpZDEwLkFDMDAxX1JTUlY5LnJlcG9ydHZlcjE0LjIwMTYxMTE2MTY1NjAzMTAucmVwb3NpdG9yeTE2LnZkcmRldl9yZWRhY3Rpb24xMC5mb2xkZXJUeXBlMTcudmRyOnJlcG9ydFZlcnNpb24xMi5yZXBvc2l0b3J5aWQzNi4wMEM5QTY1Ni00QUJBLTRFQzMtODRFNS04OEY3NTlBOUFCQTYxNi50Y2ljcnlwdG92ZXJzaW9uMy4xLjA)"
export REPOSITORY_ID="00C9A656-4ABA-4EC3-84E5-88F759A9ABA6"
export CHILDREN_COUNT="2"

echo Variable values: 
echo PROTOCOL = $PROTOCOL
echo HOST_STRING = $HOST_STRING
echo AUTHORIZATION_STRING = $AUTHORIZATION_STRING
echo REPOSITORY_ID = $REPOSITORY_ID

echo ---------------------------------------------
echo "Obtaining list of repositories (GET request)"
echo ---------------------------------------------
curl --insecure -H "Authorization:$AUTHORIZATION_STRING" -H "Host:$HOST_STRING" -H "Connection:Keep-Alive" -v "$PROTOCOL://$HOST_STRING/mobius/rest/repositories"

read -n1 -r -p "Press any key to continue..." key

echo ---------------------------------------------
echo "Obtaining repository capabilities (GET request)"
echo ---------------------------------------------
curl --insecure -H "Authorization:$AUTHORIZATION_STRING" -H "Host:$HOST_STRING" -H "Connection:Keep-Alive" -v "$PROTOCOL://$HOST_STRING/mobius/rest/repositories/$REPOSITORY_ID/capabilities"
