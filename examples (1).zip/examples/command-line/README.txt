Command Line Examples

The included batch scripts require curl (see https://curl.haxx.se/download.html). Instructions are in the scripts themselves.
The AUTHORIZATION_STRING uses standard base64 encoding of user:password (https://www.base64encode.org/ will encode your string for you.)


  curl_scripts_for_navigation_api.bat
  curl_scripts_for_repository_api.bat
  curl_scripts_for_search_api.bat

  curl_scripts_for_navigation_api.sh
  curl_scripts_for_repository_api.sh
  curl_scripts_for_search_api.sh
