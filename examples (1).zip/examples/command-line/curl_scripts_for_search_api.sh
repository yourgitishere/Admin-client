#!/bin/bash
# !!! Before using this script, replace variables below with appropriate values
export PROTOCOL="https"
export HOST_STRING="127.0.0.1:17443"
# The AUTHORIZATION_STRING uses standard base64 encoding of user:password (https://www.base64encode.org/ will encode your string for you.)
export AUTHORIZATION_STRING="Basic YWRtaW46YWRtaW4="
export REQUEST_ID="61c92f69-5ae7-401d-b110-02d62b6bcd07"
export REQUEST_ID_MODIFY="3f0edd12-b70e-4c5a-8dd2-1e10e4dbc743"
export INDEX_NAME="ACCT_DESC"
export INDEX_VALUE="aa"
export INDEX_OPERATOR="NE"
export MODIFIED_INDEX_NAME="DEPT"
export MODIFIED_INDEX_VALUE="11"
export MODIFIED_INDEX_OPERATOR="NE"
export RESULT_COUNT="2"
export REQUEST_BODY="{\"indexSearch\":{\"name\":\"Command-Line Test Search\",\"distinct\":false,\"exitOnError\":true,\"constraints\":[{\"name\":\"$INDEX_NAME\",\"values\":[{\"value\":\"$INDEX_VALUE\"}],\"operator\":\"$INDEX_OPERATOR\",\"subexpression\":null}],\"returnedIndexes\":[{\"name\":\"$INDEX_NAME\",\"sort\":{\"direction\":\"ascending\",\"precedence\":0}}],\"conjunction\":\"AND\",\"links\":null,\"repositories\":[]}}"
export MODIFY_REQUEST_BODY="{\"indexSearch\":{\"name\":\"Modified Command-Line Test Search\",\"distinct\":false,\"exitOnError\":true,\"constraints\":[{\"name\":\"$INDEX_NAME\",\"values\":[{\"value\":\"$INDEX_VALUE\"}],\"operator\":\"$INDEX_OPERATOR\",\"subexpression\":null},{\"name\":\"$MODIFIED_INDEX_NAME\",\"values\":[{\"value\":\"$MODIFIED_INDEX_VALUE\"}],\"operator\":\"$MODIFIED_INDEX_OPERATOR\",\"subexpression\":null}],\"returnedIndexes\":[{\"name\":\"$INDEX_NAME\",\"sort\":{\"direction\":\"ascending\",\"precedence\":0}},{\"name\":\"$MODIFIED_INDEX_NAME\",\"sort\":{\"direction\":\"descending\",\"precedence\":1}}],\"conjunction\":\"AND\",\"links\":null,\"repositories\":[]}}"

echo Variable values: 
echo PROTOCOL = $PROTOCOL
echo HOST_STRING = $HOST_STRING
echo AUTHORIZATION_STRING = $AUTHORIZATION_STRING
echo REQUEST_ID = $REQUEST_ID
echo RESULT_COUNT = $RESULT_COUNT

echo ---------------------------------------------
echo "Obtaining all search requests (GET request)"
echo ---------------------------------------------
curl --insecure -H "Authorization:$AUTHORIZATION_STRING" -H "Host:$HOST_STRING" -H "Connection:Keep-Alive" -v "$PROTOCOL://$HOST_STRING/mobius/rest/searches/"

read -n1 -r -p "Press any key to continue..." key

echo ---------------------------------------------
echo "Execute search request by id (GET request)"
echo ---------------------------------------------
curl --insecure -H "Authorization:$AUTHORIZATION_STRING" -H "Host:$HOST_STRING" -H "Connection:Keep-Alive" -v "$PROTOCOL://$HOST_STRING/mobius/rest/searches/$REQUEST_ID?returnresults=true&count=$RESULT_COUNT"

read -n1 -r -p "Press any key to continue..." key

echo ---------------------------------------------
echo "Execute search request (POST request)"
echo ---------------------------------------------
echo Request body:
echo $REQUEST_BODY
curl --insecure -H "Authorization:$AUTHORIZATION_STRING" -H "Host:$HOST_STRING" -H "Connection:Keep-Alive" -H "Content-Type: application/vnd.asg-mobius-search.v1+json" -X POST -d "$REQUEST_BODY" -v "$PROTOCOL://$HOST_STRING/mobius/rest/searches/?returnresults=true&count=$RESULT_COUNT"

read -n1 -r -p "Press any key to continue..." key

echo ---------------------------------------------
echo "Save search request (POST request)"
echo ---------------------------------------------
echo Request body:
echo $REQUEST_BODY
curl --insecure -H "Authorization:$AUTHORIZATION_STRING" -H "Host:$HOST_STRING" -H "Connection:Keep-Alive" -H "Content-Type: application/vnd.asg-mobius-search.v1+json" -X POST -d "$REQUEST_BODY" -v "$PROTOCOL://$HOST_STRING/mobius/rest/searches/"

read -n1 -r -p "Press any key to continue..." key

echo ---------------------------------------------
echo "Modify search request (PUT request)"
echo ---------------------------------------------
echo Request body:
echo $MODIFY_REQUEST_BODY
curl --insecure -H "Authorization:$AUTHORIZATION_STRING" -H "Host:$HOST_STRING" -H "Connection:Keep-Alive" -H "Content-Type: application/vnd.asg-mobius-search.v1+json" -X PUT -d "$MODIFY_REQUEST_BODY" -v "$PROTOCOL://$HOST_STRING/mobius/rest/searches/$REQUEST_ID_MODIFY"

read -n1 -r -p "Press any key to continue..." key

echo ---------------------------------------------
echo "Delete search request (Delete request)"
echo ---------------------------------------------
echo Request body:
echo $MODIFY_REQUEST_BODY
curl --insecure -H "Authorization:$AUTHORIZATION_STRING" -H "Host:$HOST_STRING" -H "Connection:Keep-Alive" -H "Content-Type: application/vnd.asg-mobius-search.v1+json" -X DELETE -v "$PROTOCOL://$HOST_STRING/mobius/rest/searches/$REQUEST_ID_MODIFY"
