The Mobius View Sample RM Client demonstrates several aspects of the Records Management process.

This is a separately licensed option, so make sure your license includes Records Management.

First, make sure your user belongs to the "Records Management Administrators" group if you plan to create or modify
event templates or retention policies. The Sample RM Client has a link to launch Mobius Administrator. Navigate to the
Repository Security page to configure this. Managing events requires membership in at least the "Records Management
Users" group.

Second, use RMHub to create event templates and retention policies. Chapter 8 of the Mobius View Administrator’s Guide
explains these concepts, and the Sample RM Client has a link to launch RMHub.

If you already have retention events (like holds) in place, you can access them using the "Event Processing" section of
the client. If want to post a retention event for a given event template, you can use the "Content from RMHub" section
to drill down through the event templates, record types, and retention policies.
