/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.common;

import com.asg.mobius.view.webtier.rest.client.demo.common.PropertiesHolder;
import com.asg.mobius.view.webtier.rest.client.demo.common.ResultPrinter;
import com.asg.mobius.view.webtier.rest.client.demo.common.SslTool;
import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.HttpMethod;
import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.IndexSearch;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.SearchList;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.SearchRequest;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.SearchResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.glassfish.jersey.client.JerseyClient;
import org.glassfish.jersey.client.ClientResponse;
import org.glassfish.jersey.client.JerseyWebTarget;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.jackson.JacksonFeature;


import java.io.IOException;
import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.InvocationCallback;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Configurable;
import javax.ws.rs.core.Response;

public class HttpBuilder {
    private static PropertiesHolder propertiesHolder;

    public static void setProperties(PropertiesHolder p) {
        propertiesHolder = p;
        authorization = propertiesHolder.get(PropertiesHolder.Name.AUTHORIZATION_STRING);
        hostName = propertiesHolder.get(PropertiesHolder.Name.HOSTNAME);
    }

    private static String authorization;
    private static String hostName;

    public static Invocation.Builder makeUrl(String url, String typeOfRequest) {
        System.out.println("Url Used: [" +url+"];");
        try {
            Client client = SslTool.createClient();

            client.register(JacksonFeature.class);
            WebTarget target = client.target(url);


            Invocation.Builder builder = target.request();
            if (typeOfRequest != null)
                builder = target.request(typeOfRequest);

            builder
                    .header("Authorization", authorization)
                    .header("Host", hostName)
                    .header("Connection", "Keep-Alive")
            ;


            return builder;
        }catch(Exception ex) {
            System.out.println(ex);
        }
        return null;
    }

}
