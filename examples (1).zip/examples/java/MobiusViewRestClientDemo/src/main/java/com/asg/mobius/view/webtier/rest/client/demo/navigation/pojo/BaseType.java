/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo;


public enum BaseType {
    FOLDER("folder"),
    DOCUMENT("document");

    private String value;

    BaseType(String value) {
        this.value = value;
    }
    public static BaseType fromString(String string) {
        for(BaseType v : BaseType.values()) {
            if(v.getValue().equals(string)) return v;
        }
        return null;
    }

    public String getValue() {
        return value;
    }

}
