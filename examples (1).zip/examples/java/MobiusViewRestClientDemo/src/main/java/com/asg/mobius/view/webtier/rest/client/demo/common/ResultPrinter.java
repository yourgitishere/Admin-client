/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.glassfish.jersey.client.ClientResponse;
import javax.ws.rs.core.Response;

/**
 * Utility class to print REST execution results to console
 */
public class ResultPrinter {
    private static final String RESPONSE_BODY = "Response body:";
    private static final String REQUEST_BODY = "Request body:";
    private static final String JSON = "JSON:";
    private static final String ENTITY = "Entity:";
    private static String SEPARATOR = "=====================================================";
    private static String SEPARATOR_THIN = "-----------------------------------------------------";


    public static void print(Response response, Class<?> cls) throws JsonProcessingException {
        Object responseEntity = response.readEntity(cls);
        print(response,responseEntity);
    }

    public static void print(Response response, Object responseEntity) throws JsonProcessingException {

        ResultPrinter.printRequestDetails(response);
        ResultPrinter.printResponseJson(responseEntity);
        ResultPrinter.printResponseEntity(responseEntity);
    }

    public static void printRequestDetails(Object request, Response response) throws JsonProcessingException {
        printRequestDetails(response);
        printRequestEntity(request);
    }


    public static void printRequestDetails(Response response) {
        System.out.println(SEPARATOR);
        System.out.println("Request:");
        System.out.println(response);
    }

    public static void printResponseJson(Object response) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        System.out.println(SEPARATOR);
        System.out.println(RESPONSE_BODY);
        System.out.println(JSON);
        System.out.println(mapper.writeValueAsString(response));
        System.out.println(SEPARATOR_THIN);
    }

    public static void printResponseEntity(Object response) {
        System.out.println(ENTITY);
        System.out.println(response);
        System.out.println(SEPARATOR);
    }

    public static void printRequestEntity(Object request) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        System.out.println(SEPARATOR);
        System.out.println(REQUEST_BODY);
        System.out.println(JSON);
        System.out.println(mapper.writeValueAsString(request));
        System.out.println(SEPARATOR_THIN);
        System.out.println(ENTITY);
        System.out.println(request.toString());
    }
}
