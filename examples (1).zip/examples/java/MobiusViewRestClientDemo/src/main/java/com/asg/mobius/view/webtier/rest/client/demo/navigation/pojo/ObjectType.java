/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo;

import java.util.List;


public class ObjectType {
   private String objectTypeId;
    private BaseType baseTypeId;
    private List<Property> properties;

    public String getObjectTypeId() {
        return objectTypeId;
    }

    public void setObjectTypeId(String objectTypeId) {
        this.objectTypeId = objectTypeId;
    }

    public BaseType getBaseTypeId() {
        return baseTypeId;
    }

    public void setBaseTypeId(BaseType baseTypeId) {
        this.baseTypeId = baseTypeId;
    }

    public List<Property> getProperties() {
        return properties;
    }

    public void setProperties(List<Property> properties) {
        this.properties = properties;
    }

    @Override
    public String toString() {
        return "ObjectType{" +
                "objectTypeId='" + objectTypeId + '\'' +
                ", baseTypeId=" + baseTypeId +
                ", properties=" + properties +
                '}';
    }
}
