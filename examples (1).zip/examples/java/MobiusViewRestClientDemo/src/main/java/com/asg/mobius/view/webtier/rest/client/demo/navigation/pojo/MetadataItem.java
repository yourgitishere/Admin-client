/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo;

public class MetadataItem<T>  {
    private String dataType;
    private String displayName;
    private String keyName;
    private T keyValue;
    private String keyType;
    private int keyOrdinal;

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getKeyName() {
        return keyName;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }

    public T getKeyValue() {
        return keyValue;
    }

    public void setKeyValue(T keyValue) {
        this.keyValue = keyValue;
    }

    public String getKeyType() {
        return keyType;
    }

    public void setKeyType(String keyType) {
        this.keyType = keyType;
    }

    public int getKeyOrdinal() {
        return keyOrdinal;
    }

    public void setKeyOrdinal(int keyOrdinal) {
        this.keyOrdinal = keyOrdinal;
    }

    @Override
    public String toString() {
        return "MetadataItem{" +
                "dataType='" + dataType + '\'' +
                ", displayName='" + displayName + '\'' +
                ", keyName='" + keyName + '\'' +
                ", keyValue=" + keyValue +
                ", keyType='" + keyType + '\'' +
                ", keyOrdinal=" + keyOrdinal +
                '}';
    }
}
