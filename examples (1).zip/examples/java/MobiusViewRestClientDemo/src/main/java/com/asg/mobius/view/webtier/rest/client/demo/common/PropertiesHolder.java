/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Utility class to store common properties
 */
public class PropertiesHolder {

    private Map<Name, String> propertyMap = new HashMap<>();

    public enum Name {
        PROTOCOL, HOSTNAME, REPOSITORY_ID,
        FOLDER_ID, DOCUMENT_ID, AUTHORIZATION_STRING,
        SEARCH_REQUEST_ID, SEARCH_INDEX_NAME, SEARCH_INDEX_VALUE,
        SEARCH_INDEX_OPERATOR, MODIFIED_INDEX_NAME, MODIFIED_INDEX_VALUE,
        MODIFIED_INDEX_OPERATOR, MAX_CHILDREN_NUMBER, MAX_RESULTS_NUMBER;
    }

    public PropertiesHolder() {
        loadProprtiesFromSample("sample.properties");
    }

    public PropertiesHolder(String propertiesFilePath) {
        loadProperties(propertiesFilePath);
    }

    public String get(Name name) {
        return propertyMap.get(name);
    }
    private void loadProperties(String propertiesFilePath) {
        try (InputStream input = new FileInputStream(propertiesFilePath)) {
                Properties prop = new Properties();
                prop.load(input);
                populateProperties(prop);
        } catch (IOException e) {
             System.out.println("Unable to load property file: " + propertiesFilePath + " - use default properties");
        }
    }

    private void populateProperties(Properties properties) {
        for(Name name : Name.values()) {
            findInProperties(properties, name);
        }
    }

    private void findInProperties(Properties prop, Name property) {
        if(prop.getProperty(property.name()) == null) {
            System.out.println("Failed to find property " + property.name() + " in file. Use default value : " + propertyMap.get(property)+  "!");
        } else {
            if(propertyMap.containsKey(property)) {
                propertyMap.replace(property, prop.getProperty(property.name()));
            } else {
                propertyMap.put(property, prop.getProperty(property.name()));
            }
        }
    }

    private void loadProprtiesFromSample(String fileName) {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        Properties props = new Properties();
        try(InputStream resourceStream = loader.getResourceAsStream(fileName)) {
            props.load(resourceStream);
            populateProperties(props);
        } catch (IOException e) {
            System.out.println("Unable to load default property file: " + fileName + "!");
        }
    }

}
