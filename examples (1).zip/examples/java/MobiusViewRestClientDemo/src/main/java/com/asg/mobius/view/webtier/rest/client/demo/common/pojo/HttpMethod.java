/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.common.pojo;

public enum  HttpMethod {

    GET,  POST, PUT, PATCH, DELETE, HEAD, OPTIONS

}
