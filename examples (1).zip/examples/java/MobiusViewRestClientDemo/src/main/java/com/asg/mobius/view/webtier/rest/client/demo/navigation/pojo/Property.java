/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo;

public class Property {

    private String name;
    private String displayName;
    private DataType dataType;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public DataType getDataType() {
        return dataType;
    }

    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }



    @Override
    public String toString() {
        return "Property{" +
                "name='" + getName() + '\'' +
                ", displayName='" + getDisplayName() + '\'' +
                ", dataType=" + getDataType() +
                '}';
    }
}
