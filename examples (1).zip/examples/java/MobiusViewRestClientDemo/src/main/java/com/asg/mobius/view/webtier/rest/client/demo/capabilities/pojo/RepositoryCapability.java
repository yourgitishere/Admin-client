/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.capabilities.pojo;

public class RepositoryCapability {
    private String name;
    private String displayName;
    private boolean isSupported;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public boolean getIsSupported() {
        return isSupported;
    }

    public void setIsSupported(boolean supported) {
        isSupported = supported;
    }

    @Override
    public String toString() {
        return "RepositoryCapability{" +
                "name='" + name + '\'' +
                ", displayName='" + displayName + '\'' +
                ", isSupported=" + isSupported +
                '}';
    }
}
