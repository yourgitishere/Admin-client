/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo;

import com.asg.mobius.view.webtier.rest.client.demo.capabilities.RepositoryCapabilityRestClient;
import com.asg.mobius.view.webtier.rest.client.demo.capabilities.RepositoryRestClient;
import com.asg.mobius.view.webtier.rest.client.demo.common.PropertiesHolder;
import com.asg.mobius.view.webtier.rest.client.demo.common.SearchEntityBuilder;
import com.asg.mobius.view.webtier.rest.client.demo.navigation.DocumentNavigationRestClient;
import com.asg.mobius.view.webtier.rest.client.demo.navigation.FolderNavigationRestClient;
import com.asg.mobius.view.webtier.rest.client.demo.navigation.RepositoryNavigationRestClient;
import com.asg.mobius.view.webtier.rest.client.demo.search.SearchRestClient;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.SearchRequest;
import com.asg.mobius.view.webtier.rest.client.demo.common.HttpBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;


public class ProjectRunner {

    public static void main(String[] args) throws JsonProcessingException {
        PropertiesHolder propertiesHolder = new PropertiesHolder();
        if(args.length == 0) {
            System.out.println("Name file path not specified. Use default properties!");
        } else {
            propertiesHolder = new PropertiesHolder(args[0]);
        }
        SearchEntityBuilder searchEntityBuilder =  new SearchEntityBuilder(propertiesHolder);

        HttpBuilder.setProperties(propertiesHolder);

        System.out.println("Running repository rest client:");
        new RepositoryRestClient(propertiesHolder).doGetRepositoriesRequest();

        System.out.println("Running repository capabilities rest client:");
        new RepositoryCapabilityRestClient(propertiesHolder).doGetRepositoryCapabilitiesRequest();

        System.out.println("Running repository navigation rest client:");
        new RepositoryNavigationRestClient(propertiesHolder).doGetRepositoryChildrenRequest();

        System.out.println("Running folder navigation rest client:");
        new FolderNavigationRestClient(propertiesHolder).doGetFolderChidrenRequest();

        System.out.println("Running document navigation rest client:");
        new DocumentNavigationRestClient(propertiesHolder).doGetDocumentParentsRequest();

        System.out.println("Running search rest client:");
        SearchRestClient searchRestClient = new SearchRestClient(propertiesHolder);

        //Create search request
        SearchRequest request = searchEntityBuilder.createSearchRequest();

        //Save search request
        System.out.println("Create request");
        String requestId = searchRestClient.doPostSaveSearchRequest(request);
        System.out.println("Created request id = " + requestId);
        //Execute search request
        System.out.println("Execute request");
        searchRestClient.doGetExecuteSearchByRequestId(requestId);

        //Read search request
        System.out.println("Read request");
        searchRestClient.doGetRetrieveSearchRequestById(requestId);

        //Modify search request
        System.out.println("Modify request");
        searchEntityBuilder.modifyRequest(request);
        String modifiedRequestId = searchRestClient.doPutUpdateSearchRequest(request, requestId);
        if(!requestId.equals(modifiedRequestId)) {
            System.out.println("Error during request modification : id was changed!");
        }
        System.out.println("Execute modified request");
        searchRestClient.doGetExecuteSearchByRequestId(modifiedRequestId);
        System.out.println("Delete request");
        searchRestClient.doDeleteSearchRequest(requestId);
        System.out.println("Check if request couldn't be found after deletion");
        try {
            searchRestClient.doGetRetrieveSearchRequestById(requestId);
        } catch (Exception ex) {
            if("Failed : HTTP error code : 500".equals(ex.getMessage())) {
                System.out.println("Request with id = " + requestId + " successfully deleted");
            } else {
                System.out.println("Something went wrong : " + ex.getMessage());
            }
        }

    }
}
