/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.capabilities.pojo;

import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;

import java.util.List;

public class Repository {
    private String name;

    private String repositoryId;

    private boolean supportsPasswordChange;
    private boolean archiveWriteEnabled;
    private boolean indexUpdateEnabled;
    private boolean folderServerEnabled;
    private boolean builtInFoldersEnabled;
    private boolean recordsManagementEnabled;
    private boolean isSearchable;
    private boolean isNavigable;
    private String repositoryType;

    private boolean allowPasswordChanges;

    private List<Link> links;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRepositoryId() {
        return repositoryId;
    }

    public void setRepositoryId(String repositoryId) {
        this.repositoryId = repositoryId;
    }

    public boolean getSupportsPasswordChange() {
        return supportsPasswordChange;
    }

    public void setSupportsPasswordChange(boolean supportsPasswordChange) {
        this.supportsPasswordChange = supportsPasswordChange;
    }

    public boolean getArchiveWriteEnabled() {
        return archiveWriteEnabled;
    }

    public void setArchiveWriteEnabled(boolean archiveWriteEnabled) {
        this.archiveWriteEnabled = archiveWriteEnabled;
    }

    public boolean getIndexUpdateEnabled() {
        return indexUpdateEnabled;
    }

    public void setIndexUpdateEnabled(boolean indexUpdateEnabled) {
        this.indexUpdateEnabled = indexUpdateEnabled;
    }

    public boolean getFolderServerEnabled() {
        return folderServerEnabled;
    }

    public void setFolderServerEnabled(boolean folderServerEnabled) {
        this.folderServerEnabled = folderServerEnabled;
    }

    public boolean getBuiltInFoldersEnabled() {
        return builtInFoldersEnabled;
    }

    public void setBuiltInFoldersEnabled(boolean builtInFoldersEnabled) {
        this.builtInFoldersEnabled = builtInFoldersEnabled;
    }

    public boolean getRecordsManagementEnabled() {
        return recordsManagementEnabled;
    }

    public void setRecordsManagementEnabled(boolean recordsManagementEnabled) {
        this.recordsManagementEnabled = recordsManagementEnabled;
    }

    public boolean isSearchable() {
        return isSearchable;
    }

    public void setSearchable(boolean isSearchable) {
        this.isSearchable = isSearchable;
    }

    public boolean isNavigable() {
        return isNavigable;
    }

    public void setNavigable(boolean isNavigable) {
        this.isNavigable = isNavigable;
    }

    public String getRepositoryType() {
        return repositoryType;
    }

    public void setRepositoryType(String repositoryType) {
        this.repositoryType = repositoryType;
    }

    public boolean getAllowPasswordChanges() {
        return allowPasswordChanges;
    }

    public void setAllowPasswordChanges(boolean allowPasswordChanges) {
        this.allowPasswordChanges = allowPasswordChanges;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @Override
    public String toString() {
        return "Repository{" +
                "name='" + name + '\'' +
                ", repositoryId='" + repositoryId + '\'' +
                ", supportsPasswordChange=" + supportsPasswordChange +
                ", archiveWriteEnabled=" + archiveWriteEnabled +
                ", indexUpdateEnabled=" + indexUpdateEnabled +
                ", folderServerEnabled=" + folderServerEnabled +
                ", builtInFoldersEnabled=" + builtInFoldersEnabled +
                ", recordsManagementEnabled=" + recordsManagementEnabled +
                ", isSearchable=" + isSearchable +
                ", isNavigable=" + isNavigable +
                ", repositoryType='" + repositoryType + '\'' +
                ", allowPasswordChanges=" + allowPasswordChanges +
                ", links=" + links +
                '}';
    }
}
