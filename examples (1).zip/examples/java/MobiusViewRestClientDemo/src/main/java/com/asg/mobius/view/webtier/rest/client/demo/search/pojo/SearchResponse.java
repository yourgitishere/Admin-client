/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search.pojo;


import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;

import java.util.ArrayList;
import java.util.List;

public class SearchResponse {
    private boolean incompleteResults;
    private List<Result> results;
    private List<SearchStatus> searchStatus = new ArrayList<>();
    private List<Link> links;

    public boolean isIncompleteResults() {
        return incompleteResults;
    }

    public void setIncompleteResults(boolean incompleteResults) {
        this.incompleteResults = incompleteResults;
    }

    public List<Result> getResults() {
        return results;
    }

    public void setResults(List<Result> results) {
        this.results = results;
    }

    public List<SearchStatus> getSearchStatus() {
        return searchStatus;
    }

    public void setSearchStatus(List<SearchStatus> searchStatus) {
        this.searchStatus = searchStatus;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @Override
    public String toString() {
        return "SearchResponse{" +
                "incompleteResults=" + incompleteResults +
                ", results=" + results +
                ", searchStatus=" + searchStatus +
                ", links=" + links +
                '}';
    }
}
