/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.capabilities.pojo;

import java.util.ArrayList;
import java.util.List;


public class RepositoryCapabilities {
    private List<RepositoryCapability> capabilities = new ArrayList<>();

    public List<RepositoryCapability> getCapabilities() {
        return capabilities;
    }

    public void setCapabilities(List<RepositoryCapability> capabilities) {
        this.capabilities = capabilities;
    }

    @Override
    public String toString() {
        return "RepositoryCapabilities{" +
                "capabilities=" + capabilities +
                '}';
    }
}
