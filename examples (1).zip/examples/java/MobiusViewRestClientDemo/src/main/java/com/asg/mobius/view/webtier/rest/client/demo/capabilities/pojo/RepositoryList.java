/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.capabilities.pojo;


import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;
import com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo.Pagination;

import java.util.List;

public class RepositoryList {
    private List<Repository> items;
    private Pagination pagination;
    private List<Link> links;

    public List<Repository> getItems() {
        return items;
    }

    public void setItems(List<Repository> items) {
        this.items = items;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }


    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @Override
    public String toString() {
        return "RepositoryList{" +
                "items=" + items +
                ", pagination=" + pagination +
                ", links=" + links +
                '}';
    }
}

