/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.common;

import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SearchEntityBuilder {

    private PropertiesHolder propertiesHolder;

    public SearchEntityBuilder(PropertiesHolder propertiesHolder) {
        this.propertiesHolder = propertiesHolder;
    }

    public SearchRequest createSearchRequest() {
        SearchRequest result = new SearchRequest();
        result.setIndexSearch(createIndexSearch());
        return result;
    }

    public IndexSearch createIndexSearch() {
        IndexSearch result = new IndexSearch();
        result.setName(createTimestampName());
        result.setDistinct(false);
        result.setExitOnError(true);
        result.setConjunction("AND");
        result.setConstraints(createConstraintsList());
        result.setReturnedIndexes(createReturnedIndexesList());
        result.setRepositories(createRepositoryList());
        return result;
    }

    public String createTimestampName() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return "Test " + formatter.format(LocalDateTime.now());
    }

    public List<ReturnedIndex> createReturnedIndexesList() {
        List<ReturnedIndex> result = new ArrayList<>();
        result.add(createReturnedIndex());
        return result;
    }

    public List<Repository> createRepositoryList() {
        List<Repository> result = new ArrayList<>();
        result.add(createRepository());
        return result;
    }
    public Repository createRepository() {
        Repository result = new Repository();
        result.setId(propertiesHolder.get(PropertiesHolder.Name.REPOSITORY_ID));
        return result;
    }

    public ReturnedIndex createReturnedIndex() {
        ReturnedIndex result = new ReturnedIndex();
        result.setName(propertiesHolder.get(PropertiesHolder.Name.SEARCH_INDEX_NAME));
        result.setSort(createSort());
        return result;
    }

    public ReturnedIndex createReturnedIndex(String name, String sortDirection, int sortPrecedence) {
        ReturnedIndex result = new ReturnedIndex();
        result.setName(name);
        result.setSort(createSort(sortDirection, sortPrecedence));
        return result;
    }

    public Sort createSort() {
        Sort result = new Sort();
        result.setDirection("ascending");
        result.setPrecedence(0);
        return result;
    }

    public Sort createSort(String direcrion, int precedence) {
        Sort result = new Sort();
        result.setDirection(direcrion);
        result.setPrecedence(precedence);
        return result;
    }

    public List<Constraint> createConstraintsList() {
        List<Constraint> result = new ArrayList<>();
        result.add(createConstraint());
        return result;
    }

    public Constraint createConstraint() {
        Constraint result = new Constraint();
        result.setName(propertiesHolder.get(PropertiesHolder.Name.SEARCH_INDEX_NAME));
        result.setValues(createValuesList());
        result.setOperator(propertiesHolder.get(PropertiesHolder.Name.SEARCH_INDEX_OPERATOR));
        return result;
    }

    public Constraint createConstraint(String name, String value, String operator) {
        Constraint result = new Constraint();
        result.setName(name);
        result.setValues(createValuesList(value));
        result.setOperator(operator);
        return result;
    }

    public Subexpression createSubexpression() {
        Subexpression result = new Subexpression();
        return result;
    }

    public List<Value> createValuesList(String value) {
        List<Value> result = new ArrayList<>();
        result.add(createValue(value));
        return result;
    }

    public List<Value> createValuesList() {
        List<Value> result = new ArrayList<>();
        result.add(createValue(propertiesHolder.get(PropertiesHolder.Name.SEARCH_INDEX_VALUE)));
        return result;
    }

    public List<Value> createValuesList(List<String> values) {
        return values.stream().map(value -> createValue(value)).collect(Collectors.toList());
    }

    public Value createValue(String content) {
        Value result = new Value();
        result.setValue(content);
        return result;
    }

    public void modifyRequest(SearchRequest request) {
        request.getIndexSearch().getConstraints().add(createConstraint(propertiesHolder.get(PropertiesHolder.Name.MODIFIED_INDEX_NAME),
                propertiesHolder.get(PropertiesHolder.Name.MODIFIED_INDEX_VALUE),
                propertiesHolder.get(PropertiesHolder.Name.MODIFIED_INDEX_OPERATOR)));
        request.getIndexSearch().getReturnedIndexes().add(createReturnedIndex(propertiesHolder.get(PropertiesHolder.Name.MODIFIED_INDEX_NAME), "descending", 1));
    }
}
