/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo;

import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;

import java.util.ArrayList;
import java.util.List;

public class ObjectContainer {
    private String objectId;        // opaque id string of the item
    private String baseTypeId;      // folder | document
    private String objectTypeId;    // vdr object type id
    private String name;            // name of this item
    private String description;     // description of this item
    private Integer pageCount;      // number of document pages
    private String parentRef;       // optional parent refering name of the document
    private String parentId;        // optional parent folder id of the folder
    private String path;            // optional path to the folder
    private List<MetadataItem> metadata;// metadata
    private List<ObjectContainer> items; // a list of children objects
    private List<Link> links = new ArrayList<>();

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getBaseTypeId() {
        return baseTypeId;
    }

    public void setBaseTypeId(String baseTypeId) {
        this.baseTypeId = baseTypeId;
    }

    public String getObjectTypeId() {
        return objectTypeId;
    }

    public void setObjectTypeId(String objectTypeId) {
        this.objectTypeId = objectTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPageCount() {
        return pageCount;
    }

    public void setPageCount(Integer pageCount) {
        this.pageCount = pageCount;
    }

    public String getParentRef() {
        return parentRef;
    }

    public void setParentRef(String parentRef) {
        this.parentRef = parentRef;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public List<MetadataItem> getMetadata() {
        return metadata;
    }

    public void setMetadata(List<MetadataItem> metadata) {
        this.metadata = metadata;
    }

    public List<ObjectContainer> getItems() {
        return items;
    }

    public void setItems(List<ObjectContainer> items) {
        this.items = items;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @Override
    public String toString() {
        return "ObjectContainer{" +
                "objectId='" + objectId + '\'' +
                ", baseTypeId='" + baseTypeId + '\'' +
                ", objectTypeId='" + objectTypeId + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", pageCount=" + pageCount +
                ", parentRef='" + parentRef + '\'' +
                ", parentId='" + parentId + '\'' +
                ", path='" + path + '\'' +
                ", metadata=" + metadata +
                ", items=" + items +
                ", links=" + links +
                '}';
    }
}
