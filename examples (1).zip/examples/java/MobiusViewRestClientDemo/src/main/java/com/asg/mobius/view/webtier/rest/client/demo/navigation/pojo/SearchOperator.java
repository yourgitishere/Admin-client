/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo;

public enum SearchOperator {
    CONTAINS("CT"),
    BETWEEN("BT"),
    NOT_BETWEEN("NB"),
    STARTS_WITH("SW"),
    ENDS_WITH("EW"),
    EQUALS("EQ"),
    NOT_EQUALS("NE"),
    LIKE("LK"),
    LESS_THAN("LT"),
    LESS_THAN_OR_EQUALS("LE"),
    GREATER_THAN("GT"),
    GREATER_THAN_OR_EQUALS("GE"),
    IS_NULL("NU"),
    NOT_NULL("NN"),

    IN("IN"),
    NOT_IN("NI"),
    NOT_LIKE("NK"),

    ALL_WORDS("ALLWORDS"),
    ANY_WORDS("ANYWORDS"),
    NONE_WORDS("NONEWORDS"),
    EXACT_PHRASE("EXACTPHRASE");

    private String value;

    SearchOperator(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }
}
