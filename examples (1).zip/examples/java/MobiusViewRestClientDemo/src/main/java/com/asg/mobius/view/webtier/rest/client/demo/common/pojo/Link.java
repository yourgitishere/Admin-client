/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.common.pojo;

public class Link {

    private String rel;
    private String href;
    private String title;
    private HttpMethod method;
    private Boolean isTemplated;

    /* The following fields are for auto-navigation */
    // Custom property, absent in RFC-5988 Web Linking specification
    private Boolean isNavigable;
    // Has embedded elements (links), absent in RFC-5988 Web Linking specification
    private Boolean isParent;

    public String getRel() {
        return rel;
    }

    public void setRel(String rel) {
        this.rel = rel;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public HttpMethod getMethod() {
        return method;
    }

    public void setMethod(HttpMethod method) {
        this.method = method;
    }

    public Boolean isTemplated() {
        return isTemplated;
    }

    public void setTemplated(Boolean templated) {
        isTemplated = templated;
    }

    public Boolean getNavigable() {
        return isNavigable;
    }

    public void setNavigable(Boolean navigable) {
        isNavigable = navigable;
    }

    public Boolean getParent() {
        return isParent;
    }

    public void setParent(Boolean parent) {
        isParent = parent;
    }

    @Override
    public String toString() {
        return "Link{" +
                "rel='" + rel + '\'' +
                ", href='" + href + '\'' +
                ", title='" + title + '\'' +
                ", method=" + method +
                ", isTemplated=" + isTemplated +
                ", isNavigable=" + isNavigable +
                ", isParent=" + isParent +
                '}';
    }
}

