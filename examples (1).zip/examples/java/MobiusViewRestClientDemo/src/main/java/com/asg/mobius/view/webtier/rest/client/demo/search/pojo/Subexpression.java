/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search.pojo;

import java.util.List;

public class Subexpression {
    private String conjunction = "AND";
    private List<Constraint> constraints;

    public String getConjunction() {
        return conjunction;
    }

    public void setConjunction(String conjunction) {
        this.conjunction = conjunction;
    }

    public List<Constraint> getConstraints() {
        return constraints;
    }

    public void setConstraints(List<Constraint> constraints) {
        this.constraints = constraints;
    }

    @Override
    public String toString() {
        return "Subexpression{" +
                "conjunction='" + conjunction + '\'' +
                ", constraints=" + constraints +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Subexpression that = (Subexpression) o;

        if (conjunction != null ? !conjunction.equals(that.conjunction) : that.conjunction != null) return false;
        return constraints != null ? constraints.equals(that.constraints) : that.constraints == null;

    }

    @Override
    public int hashCode() {
        int result = conjunction != null ? conjunction.hashCode() : 0;
        result = 31 * result + (constraints != null ? constraints.hashCode() : 0);
        return result;
    }
}
