/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo;


import java.util.List;

import static java.util.Arrays.asList;

public enum DataType {
    STRING("String", asList(SearchOperator.CONTAINS, SearchOperator.STARTS_WITH, SearchOperator.ENDS_WITH, SearchOperator.EQUALS, SearchOperator.NOT_EQUALS,
           SearchOperator.LIKE, SearchOperator.NOT_LIKE, SearchOperator.LESS_THAN, SearchOperator.LESS_THAN_OR_EQUALS, SearchOperator.GREATER_THAN,
           SearchOperator.GREATER_THAN_OR_EQUALS, SearchOperator.BETWEEN, SearchOperator.NOT_BETWEEN)),

    NUMBER("Number", asList(SearchOperator.BETWEEN, SearchOperator.NOT_BETWEEN, SearchOperator.EQUALS, SearchOperator.NOT_EQUALS, SearchOperator.LESS_THAN,
           SearchOperator.LESS_THAN_OR_EQUALS, SearchOperator.GREATER_THAN, SearchOperator.GREATER_THAN_OR_EQUALS)),

    BOOLEAN("Boolean", asList(SearchOperator.EQUALS, SearchOperator.NOT_EQUALS)),
    DATE("Date", asList(SearchOperator.BETWEEN, SearchOperator.NOT_BETWEEN, SearchOperator.EQUALS, SearchOperator.NOT_EQUALS, SearchOperator.LESS_THAN,
         SearchOperator.LESS_THAN_OR_EQUALS, SearchOperator.GREATER_THAN, SearchOperator.GREATER_THAN_OR_EQUALS)),
    DATE_TIME("DateTime", asList(SearchOperator.BETWEEN, SearchOperator.NOT_BETWEEN, SearchOperator.EQUALS, SearchOperator.NOT_EQUALS, SearchOperator.LESS_THAN,
              SearchOperator.LESS_THAN_OR_EQUALS, SearchOperator.GREATER_THAN, SearchOperator.GREATER_THAN_OR_EQUALS)),
    FULL_TEXT_INDEX("FullTextIndex", asList(SearchOperator.LIKE)),
    FULL_TEXT_SNIPPET("FullTextSnippet", null),
    FULL_TEXT_HITPOSITION("FullTextHitposition", null),
    MIXED("Mixed", null),
    UNKNOWN("Unknown", null);

    private String value;
    private List<SearchOperator> supportedOperators;

    DataType(String name, List<SearchOperator> supportedOperators) {
        this.value = name;
        this.supportedOperators = supportedOperators;
    }

    public String getValue() {
        return value;
    }

    public List<SearchOperator> getSupportedOperators() {
        return supportedOperators;
    }

    public static DataType fromValue(String name) {
        for (DataType dataType : values()) {
            if (name.equalsIgnoreCase(dataType.getValue()))
                return dataType;
        }
        return UNKNOWN;
    }
}
