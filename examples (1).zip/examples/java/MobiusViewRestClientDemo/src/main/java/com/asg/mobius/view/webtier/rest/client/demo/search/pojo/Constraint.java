/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search.pojo;

import java.util.List;

public class Constraint {
    private String name;
    private List<Value> values;
    private String operator;
    private Subexpression subexpression;

    @Override
    public String toString() {
        return "Constraint{" +
                "name='" + getName() + '\'' +
                ", values=" + getValues() +
                ", operator='" + getOperator() + '\'' +
                ", subexpression=" + getSubexpression() +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Value> getValues() {
        return values;
    }

    public void setValues(List<Value> values) {
        this.values = values;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Subexpression getSubexpression() {
        return subexpression;
    }

    public void setSubexpression(Subexpression subexpression) {
        this.subexpression = subexpression;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Constraint that = (Constraint) o;

        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (values != null ? !values.equals(that.values) : that.values != null) return false;
        if (operator != null ? !operator.equals(that.operator) : that.operator != null) return false;
        return subexpression != null ? subexpression.equals(that.subexpression) : that.subexpression == null;

    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (values != null ? values.hashCode() : 0);
        result = 31 * result + (operator != null ? operator.hashCode() : 0);
        result = 31 * result + (subexpression != null ? subexpression.hashCode() : 0);
        return result;
    }
}
