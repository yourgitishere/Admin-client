/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.common;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

/*
* For test purposes this class prevents SSL certification
*/
public class SslTool {

    private static  TrustManager[] getTrustManager() {
        return new TrustManager[] { new X509TrustManager() {
            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
                // Trust all servers
            }

            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
                // Trust all clients
            }
        } };
    }

    /**
     * Build a new Rest client with SSL security that trusts all certificates in
     * SSL/TLS.
     *
     * @return : new REST client
     * @throws ImClientException
     *           : generic exception in the rest client
     */
//    @Override
    public static Client createClient() throws Exception {
        try {
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, getTrustManager(), new SecureRandom());

            HostnameVerifier verifier = new HostnameVerifier() {
                @Override
                public boolean verify(String hostName, SSLSession sslSession) {
                    return true;
                }
            };

            return ClientBuilder.newBuilder().sslContext(ctx).hostnameVerifier(verifier)
                    .build();

        } catch (GeneralSecurityException exception) {
            // Log (or/and) throw exception
        }
        return null;
    }
}

