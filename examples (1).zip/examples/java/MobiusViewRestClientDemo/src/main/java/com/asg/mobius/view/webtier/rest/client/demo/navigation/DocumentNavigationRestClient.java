/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation;

import com.asg.mobius.view.webtier.rest.client.demo.common.HttpBuilder;
import com.asg.mobius.view.webtier.rest.client.demo.common.PropertiesHolder;
import com.asg.mobius.view.webtier.rest.client.demo.common.ResultPrinter;
import com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo.ObjectListContainer;
import com.fasterxml.jackson.core.JsonProcessingException;
import javax.ws.rs.core.Response;

public class DocumentNavigationRestClient {

    private PropertiesHolder propertiesHolder;

    private String requestURL;

    public DocumentNavigationRestClient (PropertiesHolder propertiesHolder) {
        this.propertiesHolder = propertiesHolder;
        this.requestURL = propertiesHolder.get(PropertiesHolder.Name.PROTOCOL)
                + propertiesHolder.get(PropertiesHolder.Name.HOSTNAME)
                + "/mobius/rest/documents/"
                + propertiesHolder.get(PropertiesHolder.Name.DOCUMENT_ID)
                + "/parents";
    }

    public void doGetDocumentParentsRequest() throws JsonProcessingException {
        Response response = HttpBuilder.makeUrl(requestURL,null).get();
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        ResultPrinter.print(response,ObjectListContainer.class);
    }
}
