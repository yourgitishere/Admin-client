/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search.pojo;

import java.util.List;

public class Snippet {
    private String text;
    private List<HitPosition> position;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public List<HitPosition> getPosition() {
        return position;
    }

    public void setPosition(List<HitPosition> position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return "Snippet{" +
                "text='" + text + '\'' +
                ", position=" + position +
                '}';
    }
}
