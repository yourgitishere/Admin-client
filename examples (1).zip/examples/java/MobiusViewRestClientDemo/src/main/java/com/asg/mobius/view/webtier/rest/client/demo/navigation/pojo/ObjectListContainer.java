/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo;

import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the result of the Navigation REST service.
 */

public class ObjectListContainer
{
    private Integer numItems;
    private Boolean hasMoreItems;
    private boolean locateSupported;
    private List<ObjectContainer> items = new ArrayList<>();
    private List<Link> links;


    public Integer getNumItems() {
        return numItems;
    }

    public void setNumItems(Integer numItems) {
        this.numItems = numItems;
    }

    public Boolean isHasMoreItems() {
        return hasMoreItems;
    }

    public void setHasMoreItems(Boolean hasMoreItems) {
        this.hasMoreItems = hasMoreItems;
    }

    public boolean isLocateSupported() {
        return locateSupported;
    }

    public void setLocateSupported(boolean locateSupported) {
        this.locateSupported = locateSupported;
    }

    public List<ObjectContainer> getItems() {
        return items;
    }

    public void setItems(List<ObjectContainer> items) {
        this.items = items;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @Override
    public String toString() {
        return "ObjectListContainer{" +
                "numItems=" + numItems +
                ", hasMoreItems=" + hasMoreItems +
                ", locateSupported=" + locateSupported +
                ", items=" + items +
                ", links=" + links +
                '}';
    }
}
