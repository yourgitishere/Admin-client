/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search.pojo;

import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;
import com.asg.mobius.view.webtier.rest.client.demo.navigation.pojo.MetadataItem;

import java.util.List;

public class Result {
    private long pageCount;
    private long pageNumber;
    private String objectId;
    private String objectTypeId;
    private List<Index> indexes = null;
    private List<MetadataItem> metadata = null;
    private List<Snippet> snippets = null;
    private List<Link> links;

    public long getPageCount() {
        return pageCount;
    }

    public void setPageCount(long pageCount) {
        this.pageCount = pageCount;
    }

    public long getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(long pageNumber) {
        this.pageNumber = pageNumber;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getObjectTypeId() {
        return objectTypeId;
    }

    public void setObjectTypeId(String objectTypeId) {
        this.objectTypeId = objectTypeId;
    }

    public List<Index> getIndexes() {
        return indexes;
    }

    public void setIndexes(List<Index> indexes) {
        this.indexes = indexes;
    }

    public List<MetadataItem> getMetadata() {
        return metadata;
    }

    public void setMetadata(List<MetadataItem> metadata) {
        this.metadata = metadata;
    }

    public List<Snippet> getSnippets() {
        return snippets;
    }

    public void setSnippets(List<Snippet> snippets) {
        this.snippets = snippets;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @Override
    public String toString() {
        return "Result{" +
                "pageCount=" + pageCount +
                ", pageNumber=" + pageNumber +
                ", objectId='" + objectId + '\'' +
                ", objectTypeId='" + objectTypeId + '\'' +
                ", indexes=" + indexes +
                ", metadata=" + metadata +
                ", snippets=" + snippets +
                ", links=" + links +
                '}';
    }
}
