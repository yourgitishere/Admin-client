/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.capabilities;


import com.asg.mobius.view.webtier.rest.client.demo.capabilities.pojo.RepositoryList;
import com.asg.mobius.view.webtier.rest.client.demo.common.HttpBuilder;
import com.asg.mobius.view.webtier.rest.client.demo.common.PropertiesHolder;
import com.asg.mobius.view.webtier.rest.client.demo.common.ResultPrinter;
import com.fasterxml.jackson.core.JsonProcessingException;
import javax.ws.rs.core.Response;

public class RepositoryRestClient {
    private PropertiesHolder propertiesHolder;
    private String requestURL;

    public RepositoryRestClient(PropertiesHolder propertiesHolder) {
        this.propertiesHolder = propertiesHolder;
        this.requestURL = propertiesHolder.get(PropertiesHolder.Name.PROTOCOL)
                + propertiesHolder.get(PropertiesHolder.Name.HOSTNAME)
                + "/mobius/rest/repositories/";
    }

    public void doGetRepositoriesRequest() throws JsonProcessingException {
        Response response = HttpBuilder.makeUrl(requestURL,null).get();
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        ResultPrinter.print(response, RepositoryList.class);
//        RepositoryList responseEntity = response.getEntity(RepositoryList.class);
    }
}
