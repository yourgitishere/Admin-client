/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search.pojo;

import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;

import java.util.List;

public class IndexSearch {
    private String name;
    private boolean distinct;
    private boolean exitOnError = true;
    private List<Constraint> constraints;
    private List<ReturnedIndex> returnedIndexes;
    private String conjunction = "AND";
    private List<Link> links;
    private List<Repository> repositories;
    private String searchId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isExitOnError() {
        return exitOnError;
    }

    public void setExitOnError(boolean exitOnError) {
        this.exitOnError = exitOnError;
    }

    public List<Constraint> getConstraints() {
        return constraints;
    }

    public void setConstraints(List<Constraint> constraints) {
        this.constraints = constraints;
    }

    public List<ReturnedIndex> getReturnedIndexes() {
        return returnedIndexes;
    }

    public void setReturnedIndexes(List<ReturnedIndex> returnedIndexes) {
        this.returnedIndexes = returnedIndexes;
    }

    public String getConjunction() {
        return conjunction;
    }

    public void setConjunction(String conjunction) {
        this.conjunction = conjunction;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    public List<Repository> getRepositories() {
        return repositories;
    }

    public void setRepositories(List<Repository> repositories) {
        this.repositories = repositories;
    }

    public String getSearchId() {
        return searchId;
    }

    public void setSearchId(String searchId) { this.searchId = searchId; }


    @Override
    public String toString() {
        return "IndexSearch{" +
                "name='" + name + '\'' +
                ", distinct=" + distinct +
                ", exitOnError=" + exitOnError +
                ", constraints=" + constraints +
                ", returnedIndexes=" + returnedIndexes +
                ", conjunction='" + conjunction + '\'' +
                ", links=" + links +
                ", repositories=" + repositories +
                ", searchId=" + searchId +
                '}';
    }
}
