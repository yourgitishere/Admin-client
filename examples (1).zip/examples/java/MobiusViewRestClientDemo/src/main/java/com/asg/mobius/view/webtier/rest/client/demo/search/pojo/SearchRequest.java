/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search.pojo;

public class SearchRequest {

    private IndexSearch indexSearch;

    public IndexSearch getIndexSearch() {
        return indexSearch;
    }

    public void setIndexSearch(IndexSearch indexSearch) {
        this.indexSearch = indexSearch;
    }

    @Override
    public String toString() {
        return "SearchRequest{" +
                "indexSearch=" + indexSearch +
                '}';
    }
}
