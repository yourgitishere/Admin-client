/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search;

import com.asg.mobius.view.webtier.rest.client.demo.common.HttpBuilder;
import com.asg.mobius.view.webtier.rest.client.demo.common.PropertiesHolder;
import com.asg.mobius.view.webtier.rest.client.demo.common.ResultPrinter;
import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.HttpMethod;
import com.asg.mobius.view.webtier.rest.client.demo.common.pojo.Link;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.IndexSearch;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.SearchList;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.SearchRequest;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.SearchResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import javax.ws.rs.core.Response;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;

/**
 * @author Andrey Gritsik.
 */
public class SearchRestClient {

    private PropertiesHolder propertiesHolder;

    private String requestURL;

    private String requestSuffix;

    public SearchRestClient (PropertiesHolder propertiesHolder) {
        this.propertiesHolder = propertiesHolder;
        this.requestURL =  propertiesHolder.get(PropertiesHolder.Name.PROTOCOL)
                + propertiesHolder.get(PropertiesHolder.Name.HOSTNAME)
                + "/mobius/rest/searches/";
        this.requestSuffix = "?returnresults=true&count=" + propertiesHolder.get(PropertiesHolder.Name.MAX_RESULTS_NUMBER);
    }

    public void doGetAllSearches() throws JsonProcessingException {

        Response response = HttpBuilder.makeUrl(requestURL,null).get();
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        ResultPrinter.print(response, SearchList.class);
    }

    public void doGetExecuteSearchByRequestId(String searchRequestId) throws JsonProcessingException {
        Response response = HttpBuilder.makeUrl(requestURL + searchRequestId + requestSuffix,null).get();
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        ResultPrinter.print(response, SearchResponse.class);
    }

    public IndexSearch doGetRetrieveSearchRequestById(String searchRequestId) throws JsonProcessingException {

        Response response = HttpBuilder.makeUrl(requestURL+ searchRequestId,null).get();
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        Object responseEntity = response.readEntity(IndexSearch.class);

        ResultPrinter.print(response, responseEntity);

        return (IndexSearch)responseEntity;
    }


    public String doPostSaveSearchRequest(SearchRequest searchRequest) throws JsonProcessingException {


        Response response = HttpBuilder.makeUrl(requestURL,"application/vnd.asg-mobius-search.v1+json").post(Entity.entity(searchRequest,"application/vnd.asg-mobius-search.v1+json"));
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        Object responseEntity = response.readEntity(IndexSearch.class);

        ResultPrinter.print(response, responseEntity);

        return getRequestId((IndexSearch)responseEntity);
    }

    private String getRequestId(IndexSearch responseEntity) {
        String requestId = null;
        for(Link link : responseEntity.getLinks()) {
            if(link.getMethod().equals(HttpMethod.PUT)) {
                String[] stringPeaces = link.getHref().split("/");
                requestId = stringPeaces[stringPeaces.length-1];
                break;
            }
        }
        return requestId;
    }

    public void doPostExecuteSearchRequest(SearchRequest searchRequest) throws JsonProcessingException {
        Response response = HttpBuilder.makeUrl(requestURL+requestSuffix,"application/vnd.asg-mobius-search.v1+json").post(Entity.entity(searchRequest,"application/vnd.asg-mobius-search.v1+json"));
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        ResultPrinter.print(response, SearchResponse.class);
    }

    public String doPutUpdateSearchRequest(SearchRequest searchRequest, String requestId) throws JsonProcessingException {

        Response response = HttpBuilder.makeUrl(requestURL+requestId,"application/vnd.asg-mobius-search.v1+json").put(Entity.entity(searchRequest,"application/vnd.asg-mobius-search.v1+json"));
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        Object responseEntity = response.readEntity(IndexSearch.class);

        ResultPrinter.print(response, responseEntity);

        return getRequestId((IndexSearch)responseEntity);
    }

    public void doDeleteSearchRequest(String requestId) throws JsonProcessingException {
        Response response = HttpBuilder.makeUrl(requestURL+requestId,null).delete();
        if (response.getStatus() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
        }
        ResultPrinter.printRequestDetails(response);
    }
}
