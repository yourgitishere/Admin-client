/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.search;

import com.asg.mobius.view.webtier.rest.client.demo.common.HttpBuilder;
import com.asg.mobius.view.webtier.rest.client.demo.common.PropertiesHolder;
import com.asg.mobius.view.webtier.rest.client.demo.common.SearchEntityBuilder;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.IndexSearch;
import com.asg.mobius.view.webtier.rest.client.demo.search.pojo.SearchRequest;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class SearchRestClientTest {

    private PropertiesHolder propertiesHolder = new PropertiesHolder();
    private SearchEntityBuilder searchEntityBuilder = new SearchEntityBuilder(propertiesHolder);

    @Before
    public void setUp() {
        HttpBuilder.setProperties(propertiesHolder);
    }

    @Test
    public void doGetAllSearchesTest() throws Exception {
        new SearchRestClient(propertiesHolder).doGetAllSearches();
    }

    @Test
    public void CRUDoperationsTest() throws Exception {
        SearchRestClient restClient = new SearchRestClient(propertiesHolder);

        //Create search request
        SearchRequest request = searchEntityBuilder.createSearchRequest();

        //Save search request
        System.out.println("Create request");
        String requestId = restClient.doPostSaveSearchRequest(request);

        //Execute search request
        System.out.println("Execute request");
        restClient.doGetExecuteSearchByRequestId(requestId);

        //Read search request
        System.out.println("Read request");
        IndexSearch readResult = restClient.doGetRetrieveSearchRequestById(requestId);
        assertTrue("Created and retrieved requests aren't equal", compareIndexSearches(request.getIndexSearch(), readResult));

        //Modify search request
        System.out.println("Modify request");
        searchEntityBuilder.modifyRequest(request);
        String modifiedRequestId = restClient.doPutUpdateSearchRequest(request, requestId);
        assertEquals("Initial and modified request ids aren't equal", requestId, modifiedRequestId);
        System.out.println("Execute modified request");
        restClient.doGetExecuteSearchByRequestId(requestId);
        System.out.println("Delete request");
        restClient.doDeleteSearchRequest(requestId);
        System.out.println("Check if request couldn't be found after deletion");
        try {
            restClient.doGetRetrieveSearchRequestById(requestId);
        } catch (Exception ex) {
            assertEquals("Failed : HTTP error code : 500", ex.getMessage());
        }

    }

    @Test
    public void doPostExecuteSearchRequestTest() throws Exception {
        new SearchRestClient(propertiesHolder).doPostExecuteSearchRequest(searchEntityBuilder.createSearchRequest());
    }

    @Test
    public void doGetSearchByRequestIdTest() throws Exception {
        new SearchRestClient(propertiesHolder).doGetExecuteSearchByRequestId(propertiesHolder.get(PropertiesHolder.Name.SEARCH_REQUEST_ID));
    }

    private boolean compareIndexSearches(IndexSearch initial, IndexSearch retrieved) {
        if (areDifferentStrings(initial.getName(), retrieved.getName())) return false;
        if (areDifferentStrings(initial.getConjunction(), retrieved.getConjunction())) return false;
        if (areDifferentLists(initial.getConstraints(), retrieved.getConstraints())) return false;
        if (areDifferentLists(initial.getRepositories(), retrieved.getRepositories())) return false;
        if (areDifferentLists(initial.getReturnedIndexes(), retrieved.getReturnedIndexes())) return false;
        return true;
    }

    private boolean areDifferentLists(List<?> list1, List<?> list2) {
        if (list1.size() != list2.size()) return true;
        if (!list1.containsAll(list2)) return true;
        return false;
    }

    private boolean areDifferentStrings(String value1, String value2) {
        return (value1 != null) && (!value1.equals(value2));
    }
}