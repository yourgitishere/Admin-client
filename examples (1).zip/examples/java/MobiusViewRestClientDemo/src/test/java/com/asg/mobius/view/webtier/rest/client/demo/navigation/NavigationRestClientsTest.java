/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.navigation;

import com.asg.mobius.view.webtier.rest.client.demo.common.HttpBuilder;
import com.asg.mobius.view.webtier.rest.client.demo.common.PropertiesHolder;
import org.junit.Before;
import org.junit.Test;

public class NavigationRestClientsTest {

    private PropertiesHolder propertiesHolder = new PropertiesHolder();

    @Before
    public void setUp() {
        HttpBuilder.setProperties(propertiesHolder);

    }

    @Test
    public void doGetRepositoryChildrenRequestTest() throws Exception {
        new RepositoryNavigationRestClient(propertiesHolder).doGetRepositoryChildrenRequest();
    }

    @Test
    public void doGetFolderChidrenRequestTest() throws Exception {
        new FolderNavigationRestClient(propertiesHolder).doGetFolderChidrenRequest();
    }

    @Test
    public void doGetDocumentParentsRequestTest() throws Exception {
        new DocumentNavigationRestClient(propertiesHolder).doGetDocumentParentsRequest();
    }
}