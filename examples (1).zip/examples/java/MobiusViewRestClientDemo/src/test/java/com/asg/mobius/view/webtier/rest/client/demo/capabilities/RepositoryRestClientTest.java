/* Copyright (C) 2019 ASG Technologies Group, Inc. All rights reserved. */

package com.asg.mobius.view.webtier.rest.client.demo.capabilities;


import com.asg.mobius.view.webtier.rest.client.demo.common.HttpBuilder;
import com.asg.mobius.view.webtier.rest.client.demo.common.PropertiesHolder;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.Before;
import org.junit.Test;

public class RepositoryRestClientTest {
    private PropertiesHolder propertiesHolder = new PropertiesHolder();

    @Before
    public void setUp() {
        HttpBuilder.setProperties(propertiesHolder);

    }

    @Test
    public void doGetRepositoriesRequestTest() throws JsonProcessingException {
        new RepositoryRestClient(propertiesHolder).doGetRepositoriesRequest();
    }
}