Java Examples

To execute the Java demo follow these steps:

1. Unzip content of MobiusViewRestClientDemo.zip.
2. Open in Java IDE as Maven project.
3. Be sure that Mobius View server is running.
There are 2 ways to run REST clients in the project:
4. Using test suites:
    a. Set your own values in the sample.properties file using your MobiusView server repositories configuration.
       You can execute the REST API DEMO to discover these values. The AUTHORIZATION_STRING uses standard base64 encoding of user:password (https://www.base64encode.org/ will encode your string for you.)
    b. Execute maven clean and test goals ('mvn clean test' from the command line in the project folder).
       You also can run NavigationRestClientsTest.java and SearchRestClientTest.java manually.

5. Run as a standalone java application.
    a. Execute maven clean and package goals without running tests ('mvn clean package -DskipTests' from the command line in the project folder).
    b. In your target directory, create your own properties file with properties like in the example below (replace values after '=' with your own):

        PROTOCOL=https://
        HOSTNAME=127.0.0.1:17443
        AUTHORIZATION_STRING=Basic YWRtaW46YWRtaW4=
        REPOSITORY_ID=00C9A656-4ABA-4EC3-84E5-88F759A9ABA6
        FOLDER_ID=ENC(OC5yZXBvcnRpZDEwLkFDMDAxX1JTUlY5LnJlcG9ydHZlcjE0LjIwMTYxMTE2MTY1NjAzMTAucmVwb3NpdG9yeTE2LnZkcmRldl9yZWRhY3Rpb24xMC5mb2xkZXJUeXBlMTcudmRyOnJlcG9ydFZlcnNpb24xMi5yZXBvc2l0b3J5aWQzNi4wMEM5QTY1Ni00QUJBLTRFQzMtODRFNS04OEY3NTlBOUFCQTYxNi50Y2ljcnlwdG92ZXJzaW9uMy4xLjA)
        DOCUMENT_ID=ENC(OC5yZXBvcnRpZDEwLkFDMDAxX1JTUlY5LnJlcG9ydHZlcjE0LjIwMTYxMTE2MTY1NjAzMTAucmVwb3J0c2VjdDQ1LiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDAwMDAwMDAwMDYwMDAwMDEwLm9yZ3BhZ2VudW0xLjExMy5udW1iZXJvZnBhZ2VzMS43MTAucmVwb3NpdG9yeTE2LnZkcmRldl9yZWRhY3Rpb24xMi5yZXBvc2l0b3J5aWQzNi4wMEM5QTY1Ni00QUJBLTRFQzMtODRFNS04OEY3NTlBOUFCQTYxNi50Y2ljcnlwdG92ZXJzaW9uMy4xLjA)
        SEARCH_REQUEST_ID=49:0
        SEARCH_INDEX_NAME=ACCT_DESC
        SEARCH_INDEX_VALUE=aa
        SEARCH_INDEX_OPERATOR=EQ
        MODIFIED_INDEX_NAME=DEPT
        MODIFIED_INDEX_VALUE=11
        MODIFIED_INDEX_OPERATOR=NE
        MAX_CHILDREN_NUMBER=5
        MAX_RESULTS_NUMBER=1

    c. Run in windows command line client ('cmd' or 'PowerShell' or similar) following command:

        java -Dfile.encoding=windows-1252 -jar mobius-view-rest-client-demo.jar "YOUR_PROPERTIES_FILE_NAME"